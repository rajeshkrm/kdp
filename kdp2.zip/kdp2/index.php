<?php
require_once('examples/tcpdf_include.php');

class MYPDF extends TCPDF {

	//Page header
	public function Header() {
		// Logo
		//$image_file = K_PATH_IMAGES.'logo_example.jpg';
		//$this->Image($image_file, 10, 10, 15, '', 'JPG', '', 'T', false, 300, '', false, false, 0, false, false, false);
		// Set font
		$this->Rect(0,0,210,297,'F','',$fill_color = array(0, 102, 51));
		$this->setFont('helvetica', 'B', 20);
		// Title
		$this->SetTextColor(255,255,255);	
		$this->SetMargins(30, 20, 15,15);
		
		//$this->Cell(0, 20, ' THE HOLLOW MANOR 2  ', 0, false, 'C', 0, '', 0, false, 'M', 'M');
	}

	// Page footer
	public function Footer() {
		// Position at 15 mm from bottom
		$this->setY(-15);
		// Set font
		$this->setFont('helvetica', 'I', 8);

		$this->Cell(40,5,'Written by Abhiram Shinde',1,10,'C');
    // Line break
      //  $this->Ln(15);	
		//$this->Cell(0,10,'Printing line number '0,1);
		// Page number
		$this->Cell(0, 10, 'Page '.$this->getAliasNumPage().'/'.$this->getAliasNbPages(), 0, false, 'C', 0, '', 0, false, 'T', 'M');
	}
	

	public function PrintChapter($num, $title, $file, $mode=false) {
		// add a new page
		//$this->AddPage();
		// disable existing columns
		//$this->resetColumns();
		// print chapter title
		//$this->ChapterTitle($num, $title);
		// set columns
		//$this->setEqualColumns(3, 57);
		// print chapter body
		//$this->ChapterBody($file, $mode);
	}

	/**
	 * Set chapter title
	 * @param int $num chapter number
	 * @param string $title chapter title
	 * @public
	 */
	public function ChapterTitle($num, $title) {
		// $this->setFont('helvetica', '', 14);
		// $this->setFillColor(200, 220, 255);
		// $this->Cell(180, 6, 'Chapter '.$num.' : '.$title, 0, 1, '', 1);
		// $this->Ln(4);
	}

	/**
	 * Print chapter body
	 * @param string $file name of the file containing the chapter body
	 * @param boolean $mode if true the chapter body is in HTML, otherwise in simple text.
	 * @public
	 */
	public function ChapterBody($file, $mode=false) {
		$this->selectColumn();
		// get esternal file content
		$content = file_get_contents($file, false);
		// set font
		$this->setFont('times', '', 9);
		$this->setTextColor(50, 50, 50);
		// print content
		if ($mode) {
			// ------ HTML MODE ------
			$this->writeHTML($content,  true, false, true, false, '');
		} else {
			// ------ TEXT MODE ------
			$this->Write(0, $content,  true, false, true, false, '');
		}
		$this->Ln();
	}
}
//$pdf = new MYPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

// create new PDF document
$pdf = new MYPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

// set document information
$pdf->setCreator(PDF_CREATOR);
//$pdf->setAuthor('Nicola Asuni');
//$pdf->setTitle('TCPDF Example 061');
$pdf->setSubject('TCPDF Tutorial');
$pdf->setKeywords('TCPDF, PDF, example, test, guide');

// set default header data
//$pdf->setHeaderData(PDF_HEADER_LOGO, PDF_HEADER_LOGO_WIDTH, PDF_HEADER_TITLE.' 061', PDF_HEADER_STRING);

// set header and footer fonts
//$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

// set default monospaced font
$pdf->setDefaultMonospacedFont(PDF_FONT_MONOSPACED);

// set margins
$pdf->setMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
$pdf->setHeaderMargin(PDF_MARGIN_HEADER);
$pdf->setFooterMargin(PDF_MARGIN_FOOTER);

// set auto page breaks
$pdf->setAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

// set image scale factor
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

// set some language-dependent strings (optional)
if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
	require_once(dirname(__FILE__).'/lang/eng.php');
	$pdf->setLanguageArray($l);
}

// ---------------------------------------------------------
// set font
$pdf->setFont('helvetica', '', 10);
// add a page
$pdf->AddPage();

/* NOTE:
 * *********************************************************
 * You can load external XHTML using :
 *
 * $html = file_get_contents('/path/to/your/file.html');
 *
 * External CSS files will be automatically loaded.
 * Sometimes you need to fix the path of the external CSS.
 * *********************************************************
 */

// define some HTML content with style
$html = <<<EOF
<!-- EXAMPLE OF CSS STYLE -->
<style>
	h1 {
		color: #ffffff;
		font-family: times;
		font-size: 50pt;
		text-align:center;
	}
	p.first {
		color: #003300;
		font-family: helvetica;
		font-size: 12pt;
	}
	p.first span {
		color: #006600;
		font-style: italic;
	}
	p#second {
		color: rgb(00,63,127);
		font-family: times;
		font-size: 12pt;
		text-align: justify;
	}
	p#second > span {
		background-color: #FFFFAA;
	}
	table.first {
		color: #003300;
		font-family: helvetica;
		font-size: 8pt;
		border-left: 3px solid red;
		border-right: 3px solid #FF00FF;
		border-top: 3px solid green;
		border-bottom: 3px solid blue;
		background-color: #ccffcc;
	}
	td {
		border: 2px solid blue;
		background-color: #ffffee;
	}
	td.second {
		border: 2px dashed green;
	}
	div.test {
		color: #CC0000;
		background-color: #FFFF66;
		font-family: helvetica;
		font-size: 10pt;
		border-style: solid solid solid solid;
		border-width: 2px 2px 2px 2px;
		border-color: green #FF00FF blue red;
		text-align: center;
	}
	.lowercase {
		text-transform: lowercase;
		margin-top:400px;
	}
	.uppercase {
		text-transform: uppercase;
	}
	.capitalize {
		text-transform: capitalize;
	}
</style>

<h1 class="title">THE HOLLOW MANOR 2   <i style="color:#990000"></i></h1>


</div>

<br />


EOF;

// get the current page break margin
$bMargin = $pdf->getBreakMargin();
// get current auto-page-break mode
$auto_page_break = $pdf->getAutoPageBreak();
// disable auto-page-break
$pdf->setAutoPageBreak(false, 0);
// set bacground image
$img_file = K_PATH_IMAGES.'thailand-in-pictures-most-beautiful-places-railay-beach.jpg';
$pdf->Image($img_file, null, 0, 210, 297, '', '', '', false, 300, 'C', false, false, 0);

// restore auto-page-break status
$pdf->setAutoPageBreak($auto_page_break, $bMargin);
// set the starting point for the page content
//$pdf->Cell(10, 0, ' THE HOLLOW MANOR 6  ', 0, false, 'C', 0, '', 0, false, 'M', 'M');

$pdf->setPageMark();

// print TEXT
//$pdf->PrintChapter(1, 'LOREM IPSUM [TEXT]', 'examples/data/chapter_demo_1.txt', false);

// print HTML
// output the HTML content
$pdf->writeHTML($html, true, false, true, false, '');

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -



$pdf->AddPage();


$html = '
<h1>HTML TIPS & TRICKS</h1>

<h3>REMOVE CELL PADDING</h3>
<p style="color:#fff">
This is used to adjust the conversion ratio between pixels and document units. Increase the value to get smaller objects.<br />
Since you are using pixel unit, this method is important to set theright zoom factor.<br /><br />
Suppose that you want to print a web page larger 1024 pixels to fill all the available page width.<br />
An A4 page is larger 210mm equivalent to 8.268 inches, if you subtract 13mm (0.512") of margins for each side, the remaining space is 184mm (7.244 inches).<br />
</p>';

// output the HTML content
//$pdf->writeHTML($html, true, false, true, false, '');

$pdf->setAutoPageBreak(false, 0);
// set bacground image
$img_file = K_PATH_IMAGES.'2908962 (1).jpg';
$pdf->Image($img_file, null, 0, 210, 297, '', '', '', false, 300, 'C', false, false, 0);

// restore auto-page-break status
$pdf->setAutoPageBreak($auto_page_break, $bMargin);
// set the starting point for the page content
//$pdf->Cell(10, 0, ' THE HOLLOW MANOR 6  ', 0, false, 'C', 0, '', 0, false, 'M', 'M');

$pdf->setPageMark();

$pdf->writeHTML($html, true, false, true, false, '');



// add a page
$pdf->AddPage();

$html = '
<h1 style="color:#fff">THE HOLLOW MANOR 2</h1>
<h5 style="color:#fff">Written by Abhiram Shinde</h5>
';


// output the HTML content
//$pdf->SetMargins(30, 110, 10,110);
$pdf->writeHTML($html, true, false, true, false, '');
//$pdf->writeHTML($content,  true, false, true, false, '');
// reset pointer to the last page


$pdf->Ln();

$pdf->setLineStyle(array('width' => 0.5, 'cap' => 'butt', 'join' => 'miter', 'dash' => 4, 'color' => array(255, 0, 0)));
$pdf->setFillColor(255,255,128);
$pdf->setTextColor(0,0,128);

$text="I will try to upload part three of this ,  My Dear Brothers and Sisters";
$image = '<img src="images/image_demo.jpg" width="54mm" height="80mm" />';
//$pdf->Cell(0, 0, $text, 1, 1, 'L', 1, 0);

//$pdf->Ln();

$pdf->setLineStyle(array('width' => 0.5, 'cap' => 'butt', 'join' => 'miter', 'dash' => 0, 'color' => array(0, 0, 255)));
$pdf->setFillColor(255,255,0);
$pdf->setTextColor(0,0,255);
$pdf->writeHTMLCell(60, 0, 10, 30, '<img width="54mm" height="50mm" src="images/image_demo.jpg" /> ');
//$pdf->MultiCell(90, 5, $image, 1, 'C', 1, 0);

$pdf->setLineStyle(array('width' => 0.5, 'color' => array(255, 255, 0)));
$pdf->setFillColor(0, 102, 51);
$pdf->setTextColor(255,255,0);
$pdf->MultiCell(90, 5, $text, '', 'C', 1, 0);
$pdf->Ln(55.5);


$html = '
<hr style="color:#fff">';

// output the HTML content
//$pdf->SetMargins(30, 110, 10,110);
$pdf->writeHTML($html, true, false, true, false, '');
 

$html2 = '<h1 style="color:#fff">Publish By BreBooks</h1><p style="color:#fff">We believe that in a world where technology impacts every aspect of our lives, our children must become active writers and passionate readers. Our mission is to provide every child with a voice , the ability to write for enjoyment, the desire to read, and the passion to become exceptional storytellers. Our powerful technology allows our children to easily publish their beautiful books on BriBooks and Amazon Global with total creative freedom

</p>';

// Print text using writeHTMLCell()
$pdf->writeHTMLCell(0, 0, '', '', $html2, 0, 10, 10, true, 'J', true);

$pdf->Ln(10);;


$html = '
<hr style="color:#fff">';

// output the HTML content
//$pdf->SetMargins(30, 110, 10,110);
$pdf->writeHTML($html, true, false, true, false, '');

$pdf->Ln(10);

	  $pdf->selectColumn();
		// get esternal file content
		$content = file_get_contents('data/chapter_demo_2.txt', false);
		// set font
		$pdf->setFont('times', '', 9);
		$pdf->setTextColor(50, 50, 50);
		// print content
			// ------ HTML MODE ------
			$pdf->writeHTML($content,  true, false, true, false, '');
			// ------ TEXT MODE ------
	

$pdf->lastPage();

// ---------------------------------------------------------

//Close and output PDF document
$pdf->Output('example_061.pdf', 'I');

//============================================================+
// END OF FILE
//============================================================+
